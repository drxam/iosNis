//
//  WishMakerViewController.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 23.10.2024.
//

import UIKit

final class WishMakerViewController: UIViewController {
    // MARK: - Variables
    private var isStackHidden = false
    
    // MARK: - Constants
    private let wishMakerView = WishMakerView()
    private let wishStoringViewController = WishStoringViewController()
    private let wishCalendarViewController = WishCalendarViewController()
    
    // MARK: - Lifecycle
    override func loadView() {
        self.view = wishMakerView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureCallbacks()
        updateBackgroundAndTextColor()
    }
    
    // MARK: - Private Methods
    private func configureCallbacks() {
        wishMakerView.onColorChange = { [weak self] color in
            AppState.shared.globalColor = color
            self?.updateBackgroundAndTextColor(to: color)
            self?.wishStoringViewController.updateBackgroundColor(color)
            self?.wishCalendarViewController.updateBackgroundColor(color)
            
            self?.navigationController?.navigationBar.titleTextAttributes = [
                .foregroundColor: AppState.shared.globalColor.inverted()
            ]
            self?.navigationController?.navigationBar.tintColor = AppState.shared.globalColor.inverted()
        }
        
        wishMakerView.onToggleButtonPressed = { [weak self] in
            self?.toggleStackVisibility()
        }
        
        wishMakerView.onWishButtonPressed = { [weak self] in
            self?.addWish()
        }
        
        wishMakerView.onScheduleButtonPressed = { [weak self] in
            self?.showCalender()
        }
    }
    
    private func updateBackgroundAndTextColor(to color: UIColor? = nil) {
        let backgroundColor = color ?? UIColor(
            red: CGFloat(wishMakerView.redSliderValue),
            green: CGFloat(wishMakerView.greenSliderValue),
            blue: CGFloat(wishMakerView.blueSliderValue),
            alpha: CGFloat(wishMakerView.alphaSliperValue)
        )
        
        wishMakerView.updateBackgroundColor(to: backgroundColor)
        wishMakerView.updateTextColor(to: backgroundColor.inverted())
        wishMakerView.updateButtonColor(to: backgroundColor, backgroundColor: backgroundColor.inverted())
    }
    
    private func toggleStackVisibility() {
        isStackHidden.toggle()
        wishMakerView.setStackVisibility(isHidden: isStackHidden)
        wishMakerView.updateButtonTitle(isHidden: isStackHidden)
    }
    
    private func addWish() {
        present(wishStoringViewController, animated: true)
    }
    
    private func showCalender() {
        navigationController?.pushViewController(wishCalendarViewController, animated: true)
    }
}

