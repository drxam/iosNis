//
//  WishEventCreationViewController.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 25.11.2024.
//

import UIKit

class WishEventCreationViewController: UIViewController {
    // MARK: - Variables
    var onWishEventCreated: ((WishEventModel) -> Void)?
    
    // MARK: - Constants
    let wishEventCreationView = WishEventCreationView()
    
    // MARK: - Lifecycle
    override func loadView() {
        self.view = wishEventCreationView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AppState.shared.globalColor
        
        wishEventCreationView.onButtonTapped = { [weak self] title, note, startDate, endDate in
            guard let self = self else { return }
            
            let wishEventModel = WishEventModel(title: title, note: note, startDate: startDate, endDate: endDate)
            self.onWishEventCreated!(wishEventModel)
            self.dismiss(animated: true)
        }
    }
    
    // MARK: - Public Methods
    func updateBackgroundColor(_ color: UIColor) {
        view.backgroundColor = color
        wishEventCreationView.backPin.backgroundColor = color.inverted()
    }
}
