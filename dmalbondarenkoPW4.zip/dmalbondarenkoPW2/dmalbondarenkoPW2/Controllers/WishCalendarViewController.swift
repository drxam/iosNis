//
//  WishCalendarViewController.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 24.11.2024.
//

import UIKit
import CoreData

class WishCalendarViewController: UIViewController {
    // MARK: - Variables
    internal var wishEventArray: [WishEventModel] = []
    
    // MARK: - Constants
    let wishCalendarView = WishCalendarView()
    let calendarManager = CalendarManager()
    let wishEventCreationViewController = WishEventCreationViewController()
    
    // MARK: - Lifecycle
    override func loadView() {
        self.view = wishCalendarView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureNavigationBar()
        configureCollectionView()
        wishEventArray = loadWishEvents()
        wishCalendarView.collectionView.reloadData()
    }
    
    // MARK: - Public Methods
    func updateBackgroundColor(_ color: UIColor) {
        wishCalendarView.backgroundColor = color
        wishCalendarView.collectionView.backgroundColor = color
        wishEventCreationViewController.updateBackgroundColor(color)
    }
    
    // MARK: - Private Methods
    private func configureCollectionView() {
        wishCalendarView.collectionView.delegate = self
        wishCalendarView.collectionView.dataSource = self
        
        if let layout = wishCalendarView.collectionView.collectionViewLayout as?
            UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = 0
            layout.minimumLineSpacing = 0
            layout.invalidateLayout()
        }
        wishCalendarView.collectionView.register(WishEventCell.self, forCellWithReuseIdentifier: WishEventCell.reuseId)
    }
    
    private func configureNavigationBar() {
        self.navigationItem.title = "Wish Calendar"
        self.navigationController?.navigationBar.titleTextAttributes = [
            .foregroundColor: AppState.shared.globalColor.inverted()
        ]
        self.navigationController?.navigationBar.tintColor = AppState.shared.globalColor.inverted()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addCalendarEvent))
    }
    
    @objc private func addCalendarEvent() {
        wishEventCreationViewController.onWishEventCreated = { [weak self] model in
            guard let self = self else { return }
            
            self.saveWishEvent(model)
            self.saveWishToCalendar(model)
            
            self.wishEventArray.append(model)
            self.wishCalendarView.collectionView.reloadData()
        }
        
        present(wishEventCreationViewController, animated: true)
    }
    
    private func saveWishEvent(_ model: WishEventModel) {
        let context = CoreDataManager.shared.context
        let wishEvent = WishEvent(context: context)
        
        wishEvent.title = model.title
        wishEvent.note = model.note
        wishEvent.startDate = model.startDate
        wishEvent.endDate = model.endDate
        
        CoreDataManager.shared.saveContext()
    }
    
    private func loadWishEvents() -> [WishEventModel] {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<WishEvent> = WishEvent.fetchRequest()
        
        do {
            let wishEvents = try context.fetch(fetchRequest)
            
            return wishEvents.map { WishEventModel(from: $0) }
        } catch {
            print("Error loading Wish Events: \(error)")
            return []
        }
    }
    
    private func saveWishToCalendar(_ model: WishEventModel) {
        let success = calendarManager.create(eventModel: model)
        if success {
            print("Event successfully created in calendar!")
        } else {
            print("Failed to create event.")
        }
    }
}
