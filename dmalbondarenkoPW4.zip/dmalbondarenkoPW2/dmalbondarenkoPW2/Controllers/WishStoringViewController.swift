//
//  WishStoringViewController.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 03.11.2024.
//

import UIKit

final class WishStoringViewController: UIViewController {
    // MARK: - Variables
    internal var wishArray: [String] = []
    
    // MARK: - Constants
    internal let userDefaultsHelper: UserDefaultsHelper = UserDefaultsHelper()
    internal let wishStoringView = WishStoringView()
    
    // MARK: - Lifecycle Methods
    override func loadView() {
        self.view = wishStoringView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AppState.shared.globalColor
        
        wishArray = userDefaultsHelper.loadWishes()
        wishStoringView.setTableDataSource(self)
    }
    
    // MARK: - Public Methods
    func updateBackgroundColor(_ color: UIColor) {
        view.backgroundColor = color
        wishStoringView.backPin.backgroundColor = color.inverted()
        wishStoringView.table.backgroundColor = color.inverted()
        wishStoringView.table.reloadData()
    }
    
    // MARK: - Private Methods
    internal func handleEditWish(at index: Int) {
        let currentWish = wishArray[index]
        
        let alertController = UIAlertController(title: Constants.WishStoringViewController.alertEditTitle, message: nil, preferredStyle: .alert)
        alertController.addTextField { textField in
            textField.text = currentWish
        }
        
        let saveAction = UIAlertAction(title: Constants.WishStoringViewController.alertSaveTitle, style: .default) { [weak self] _ in
            guard let updatedWish = alertController.textFields?.first?.text, !updatedWish.isEmpty else { return }
            self?.wishArray[index] = updatedWish
            self?.userDefaultsHelper.saveWishes(self?.wishArray ?? [])
            self?.wishStoringView.table.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: Constants.WishStoringViewController.alertCancelTitle, style: .cancel, handler: nil)
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
}
