//
//  WishCalendarView.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 24.11.2024.
//

import UIKit

class WishCalendarView: UIView {
    // MARK: - UI Components
    let collectionView: UICollectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    // MARK: - Initialization
    init() {
        super.init(frame: .zero)
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        configureCollection()
        backgroundColor = AppState.shared.globalColor
        collectionView.backgroundColor = AppState.shared.globalColor
    }
    
    private func configureCollection() {
        collectionView.backgroundColor = Constants.WishCalendarView.collectionBackgroundColor
        collectionView.alwaysBounceVertical = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.contentInset = Constants.WishCalendarView.collectionContentInset
        
        addSubview(collectionView)
        
        collectionView.pinHorizontal(to: self)
        collectionView.pinBottom(to: bottomAnchor)
        collectionView.pinTop(to: safeAreaLayoutGuide.topAnchor)
    }
}
