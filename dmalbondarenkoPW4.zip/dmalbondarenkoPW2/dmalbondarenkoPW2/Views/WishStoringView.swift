//
//  WishStoringView.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 03.11.2024.
//

import UIKit

final class WishStoringView: UIView {
    // MARK: - Constants
    let table: UITableView = UITableView(frame: .zero)
    let backPin: UIView = UIView()
    
    // MARK: - Initializer
    init() {
        super.init(frame: .zero)
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func setTableDataSource(_ dataSource: UITableViewDataSource) {
        table.dataSource = dataSource
    }
    
    func updateBackgroundColor(_ color: UIColor) {
        backgroundColor = color
        table.backgroundColor = color.inverted()
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        configureBackPin()
        configureTable()
    }
    
    private func configureBackPin() {
        addSubview(backPin)
        backPin.pinTop(to: topAnchor, Constants.WishStoringView.backPinTopOffset)
        backPin.setHeight(Constants.WishStoringView.backPinHeight)
        backPin.setWidth(Constants.WishStoringView.backPinWidth)
        backPin.pinCenterX(to: centerXAnchor)
        backPin.backgroundColor = AppState.shared.globalColor.inverted()
        backPin.layer.cornerRadius = Constants.WishStoringView.backPinCornerRadius
    }

    
    private func configureTable() {
        addSubview(table)
        table.backgroundColor = AppState.shared.globalColor.inverted()
        table.separatorStyle = .none
        table.layer.cornerRadius = Constants.WishStoringView.tableCornerRadius
        table.register(AddWishCell.self, forCellReuseIdentifier: AddWishCell.reuseId)
        table.register(WrittenWishCell.self, forCellReuseIdentifier: WrittenWishCell.reuseId)
        
        table.pin(to: self, Constants.WishStoringView.tableOffset)
    }
}
