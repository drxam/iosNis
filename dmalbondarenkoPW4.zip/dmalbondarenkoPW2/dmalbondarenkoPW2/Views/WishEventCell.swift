//
//  WishEventCell.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 24.11.2024.
//

import UIKit

class WishEventCell: UICollectionViewCell {
    // MARK: - Constants
    static let reuseId: String = "WishEventCell"
    private let wrapView: UIView = UIView()
    private let titleLabel: UILabel = UILabel()
    private let descriptionLabel: UILabel = UILabel()
    private let startDateLabel: UILabel = UILabel()
    private let endDateLabel: UILabel = UILabel()
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func configure(with event: WishEventModel) {
        titleLabel.text = event.title
        descriptionLabel.text = event.note
        startDateLabel.text = "Start Date: \(convertDateToString(event.startDate))"
        endDateLabel.text = "End Date: \(convertDateToString(event.endDate))"
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        configureWrap()
        configureTitleLabel()
        configureDescriptionLabel()
        configureEndDateLabel()
        configureStartDateLabel()
    }
    
    private func configureWrap() {
        addSubview(wrapView)
        wrapView.pin(to: self, Constants.WishEventCell.wrapPadding)
        wrapView.layer.cornerRadius = Constants.WishEventCell.tableCornerRadius
        wrapView.backgroundColor = Constants.WishEventCell.wrapBackgroundColor
    }
    
    private func configureTitleLabel() {
        addSubview(titleLabel)
        titleLabel.textColor = Constants.WishEventCell.titleLabelTextColor
        titleLabel.font = Constants.WishEventCell.titleLabelFont
        titleLabel.pinTop(to: wrapView, Constants.WishEventCell.titleLabelTopPadding)
        titleLabel.pinLeft(to: wrapView, Constants.WishEventCell.titleLabelLeftPadding)
        titleLabel.pinRight(to: wrapView.centerXAnchor, Constants.WishEventCell.titleLabelRightPadding)
        titleLabel.setHeight(Constants.WishEventCell.titleLabelHeight)
    }
    
    private func configureDescriptionLabel() {
        addSubview(descriptionLabel)
        descriptionLabel.textColor = Constants.WishEventCell.descriptionLabelTextColor
        descriptionLabel.font = Constants.WishEventCell.descriptionLabelFont
        descriptionLabel.textAlignment = .left
        descriptionLabel.numberOfLines = 0
        descriptionLabel.pinTop(to: titleLabel.bottomAnchor)
        descriptionLabel.pinLeft(to: wrapView.leadingAnchor, Constants.WishEventCell.descriptionLabelLeftPadding)
        descriptionLabel.pinRight(to: wrapView.centerXAnchor, Constants.WishEventCell.descriptionLabelRightPadding)
        descriptionLabel.pinBottom(to: wrapView.bottomAnchor, Constants.WishEventCell.descriptionLabelBottomPadding)
    }
    
    private func configureStartDateLabel() {
        addSubview(startDateLabel)
        startDateLabel.textColor = Constants.WishEventCell.startDateLabelTextColor
        startDateLabel.font = Constants.WishEventCell.startDateLabelFont
        startDateLabel.textAlignment = .center
        startDateLabel.numberOfLines = 0
        startDateLabel.pinLeft(to: wrapView.centerXAnchor, Constants.WishEventCell.startDateLabelSpacing)
        startDateLabel.pinRight(to: endDateLabel.leadingAnchor, Constants.WishEventCell.startDateLabelSpacing)
        startDateLabel.pinCenterY(to: wrapView)
    }
    
    private func configureEndDateLabel() {
        addSubview(endDateLabel)
        endDateLabel.textColor = Constants.WishEventCell.endDateLabelTextColor
        endDateLabel.font = Constants.WishEventCell.endDateLabelFont
        endDateLabel.textAlignment = .center
        endDateLabel.numberOfLines = 0
        endDateLabel.pinRight(to: wrapView.trailingAnchor, Constants.WishEventCell.endDateLabelRightPadding)
        endDateLabel.setWidth(Constants.WishEventCell.endDateLabelWidth)
        endDateLabel.pinCenterY(to: wrapView)
    }
    
    private func convertDateToString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = Constants.WishEventCell.dateFormatterFormat
        return formatter.string(from: date)
    }
}
