//
//  CustomSlider.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 23.10.2024.
//

import Foundation
import UIKit

final class CustomSlider: UIView {
    
    // MARK: - Properties
    var valueChanged: ((Double) -> Void)?
    var slider = UISlider()
    var titleView = UILabel()
    
    // MARK: - Initializer
    init(title: String, min: Double, max: Double) {
        super.init(frame: .zero)
        titleView.text = title
        slider.minimumValue = Float(min)
        slider.maximumValue = Float(max)
        slider.value = Constants.CustomSlider.sliderValue
        slider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        backgroundColor = .white
        addSubview(slider)
        addSubview(titleView)

        titleView.pinCenterX(to: centerXAnchor)
        titleView.pinTop(to: topAnchor, Constants.CustomSlider.titleTop)
        titleView.pinLeft(to: leadingAnchor, Constants.CustomSlider.titleLeft)

        slider.pinCenterX(to: centerXAnchor)
        slider.pinTop(to: titleView.bottomAnchor)
        slider.pinBottom(to: bottomAnchor, Constants.CustomSlider.sliderBottom)
        slider.pinLeft(to: leadingAnchor, Constants.CustomSlider.sliderLeft)
    }
    
    @objc private func sliderValueChanged() {
        valueChanged?(Double(slider.value))
    }
}
