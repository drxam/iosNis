//
//  WrittenWishCell.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 04.11.2024.
//

import UIKit

final class WrittenWishCell: UITableViewCell {
    // MARK: - Fields
    static let reuseId: String = "WrittenWishCell"
    private let wishLabel: UILabel = UILabel()
    let deleteWishButton: UIButton = UIButton(type: .system)
    let editWishButton: UIButton = UIButton(type: .system)
    private let wrap: UIView = UIView()
    
    // MARK: - Properties
    var deleteWish: (() -> Void)?
    var editWish: (() -> Void)?
    
    // MARK: - Lifecycle Methods
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func configure(with wish: String) {
        wishLabel.text = wish
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        selectionStyle = .none
        backgroundColor = .clear
        
        contentView.addSubview(wrap)
        wrap.addSubview(wishLabel)
        wrap.addSubview(deleteWishButton)
        wrap.addSubview(editWishButton)
        
        configureWrap()
        configureButton()
        configureEditButton()
        configureLabel()
    }
    
    private func configureWrap() {
        wrap.backgroundColor = Constants.WrittenWishCell.wrapColor
        wrap.layer.cornerRadius = Constants.WrittenWishCell.wrapRadius
        wrap.pinVertical(to: contentView, Constants.WrittenWishCell.wrapOffsetV)
        wrap.pinHorizontal(to: contentView, Constants.WrittenWishCell.wrapOffsetH)
    }
    
    private func configureButton() {
        deleteWishButton.setTitle(Constants.WrittenWishCell.deleteButtonTitle, for: .normal)
        deleteWishButton.setTitleColor(Constants.WrittenWishCell.deleteButtonTitleColor, for: .normal)
        deleteWishButton.backgroundColor = Constants.WrittenWishCell.deleteButtonBackgroundColor
        deleteWishButton.layer.cornerRadius = Constants.WrittenWishCell.buttonCornerRadius
        deleteWishButton.titleLabel?.font = .systemFont(ofSize: Constants.WrittenWishCell.buttonFontSize)
        
        deleteWishButton.pinVertical(to: wrap)
        deleteWishButton.pinRight(to: wrap)
        deleteWishButton.setWidth(Constants.WrittenWishCell.buttonWidth)
        
        deleteWishButton.addTarget(self, action: #selector(deleteWishButtonTapped), for: .touchUpInside)
    }
    
    private func configureEditButton() {
        editWishButton.setTitle(Constants.WrittenWishCell.editButtonTitle, for: .normal)
        editWishButton.setTitleColor(Constants.WrittenWishCell.editButtonTitleColor, for: .normal)
        editWishButton.backgroundColor = Constants.WrittenWishCell.editButtonBackgroundColor
        editWishButton.layer.cornerRadius = Constants.WrittenWishCell.buttonCornerRadius
        editWishButton.titleLabel?.font = .systemFont(ofSize: Constants.WrittenWishCell.buttonFontSize)
        
        editWishButton.pinVertical(to: wrap)
        editWishButton.pinRight(to: deleteWishButton.leadingAnchor, Constants.WrittenWishCell.wishLabelOffset)
        editWishButton.setWidth(Constants.WrittenWishCell.buttonWidth)
        
        editWishButton.addTarget(self, action: #selector(editWishButtonTapped), for: .touchUpInside)
    }
    
    private func configureLabel() {
        wishLabel.pinVertical(to: wrap, Constants.WrittenWishCell.wishLabelOffset)
        wishLabel.pinLeft(to: wrap.leadingAnchor, Constants.WrittenWishCell.wishLabelOffset)
        wishLabel.pinRight(to: editWishButton.leadingAnchor, Constants.WrittenWishCell.wishLabelOffset)
        wishLabel.font = .systemFont(ofSize: Constants.WrittenWishCell.labelFontSize)
        wishLabel.numberOfLines = .zero
        wishLabel.lineBreakMode = .byWordWrapping
    }
    
    @objc private func deleteWishButtonTapped() {
        deleteWish?()
    }
    
    @objc private func editWishButtonTapped() {
        editWish?()
    }
}
