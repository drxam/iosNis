//
//  WishMakerView.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 28.10.2024.
//

import UIKit

final class WishMakerView: UIView {
    
    // MARK: - UI Elements
    private let titleView = UILabel()
    private let descr = UILabel()
    let stack = UIStackView()
    private let toggleButton: UIButton = UIButton(type: .system)
    private let addWishButton: UIButton = UIButton(type: .system)
    private let scheduleButton: UIButton = UIButton(type: .system)
    private let sliderRed = CustomSlider(title: Constants.WishMakerView.red, min: Constants.WishMakerView.sliderMin, max: Constants.WishMakerView.sliderMax)
    private let sliderGreen = CustomSlider(title: Constants.WishMakerView.green, min: Constants.WishMakerView.sliderMin, max: Constants.WishMakerView.sliderMax)
    private let sliderBlue = CustomSlider(title: Constants.WishMakerView.blue, min: Constants.WishMakerView.sliderMin, max: Constants.WishMakerView.sliderMax)
    private var toggleButtonBottomConstraint: NSLayoutConstraint?
    private var isToggleButtonPinnedToStack = true
    
    // MARK: - Callbacks
    var onColorChange: ((UIColor) -> Void)?
    var onToggleButtonPressed: (() -> Void)?
    var onWishButtonPressed: (() -> Void)?
    var onScheduleButtonPressed: (() -> Void)?
    
    // MARK: - Properties
    var redSliderValue: Float { sliderRed.slider.value }
    var greenSliderValue: Float { sliderGreen.slider.value }
    var blueSliderValue: Float { sliderBlue.slider.value }
    var currentColor: UIColor { UIColor(
        red: CGFloat(redSliderValue),
        green: CGFloat(greenSliderValue),
        blue: CGFloat(blueSliderValue),
        alpha: Constants.WishMakerView.alphaValue
    ) }
    var alphaSliperValue = Constants.WishMakerView.alphaValue
    
    // MARK: - Initializer
    init() {
        super.init(frame: .zero)
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func updateTextColor(to color: UIColor) {
        titleView.textColor = color
        descr.textColor = color
    }
    
    func updateButtonColor(to titleColor: UIColor, backgroundColor: UIColor) {
        toggleButton.setTitleColor(titleColor, for: .normal)
        addWishButton.setTitleColor(titleColor, for: .normal)
        scheduleButton.setTitleColor(titleColor, for: .normal)
        
        toggleButton.backgroundColor = backgroundColor
        addWishButton.backgroundColor = backgroundColor
        scheduleButton.backgroundColor = backgroundColor
    }
    
    func updateBackgroundColor(to color: UIColor) {
        backgroundColor = color
    }
    
    func setStackVisibility(isHidden: Bool) {
        stack.isHidden = isHidden
    }
    
    func updateButtonTitle(isHidden: Bool) {
        toggleButton.setTitle(isHidden ? Constants.WishMakerView.buttonTitleShow : Constants.WishMakerView.buttonTitleHide, for: .normal)
    }
    
    // MARK: - Private Methods
    private func configureUI() {
        backgroundColor = UIColor(
            red: Constants.WishMakerView.colorValue,
            green: Constants.WishMakerView.colorValue,
            blue: Constants.WishMakerView.colorValue,
            alpha: Constants.WishMakerView.alphaValue
        )
        configureTitle()
        configureDescription()
        configureScheduleButton()
        configureAddWishButton()
        configureSliders()
        configureToggleButton()
    }
    
    private func configureTitle() {
        titleView.text = Constants.WishMakerView.titleText
        titleView.font = UIFont.boldSystemFont(ofSize: Constants.WishMakerView.titleSize)
        
        addSubview(titleView)
        titleView.pinTop(to: safeAreaLayoutGuide.topAnchor, Constants.WishMakerView.titleTopPadding)
        titleView.pinCenterX(to: self)
    }
    
    private func configureDescription() {
        descr.text = Constants.WishMakerView.descriptionText
        descr.font = UIFont.systemFont(ofSize: Constants.WishMakerView.descriptionSize)
        descr.numberOfLines = .zero
        descr.lineBreakMode = .byWordWrapping
        
        addSubview(descr)
        descr.pinLeft(to: self, Constants.WishMakerView.descriptionPadding)
        descr.pinRight(to: self, Constants.WishMakerView.descriptionPadding)
        descr.pinTop(to: titleView.bottomAnchor, Constants.WishMakerView.descriptionPadding)
    }
    
    private func configureSliders() {
        stack.axis = .vertical
        stack.layer.cornerRadius = Constants.WishMakerView.stackRadius
        stack.layer.borderWidth = Constants.WishMakerView.borderWidth
        stack.clipsToBounds = true
        
        addSubview(stack)
        for slider in [sliderRed, sliderGreen, sliderBlue] {
            stack.addArrangedSubview(slider)
            slider.valueChanged = { [weak self] _ in self?.notifyColorChange() }
        }
        
        stack.pinCenterX(to: self)
        stack.pinLeft(to: self.leadingAnchor, Constants.WishMakerView.stackLeading)
        stack.pinBottom(to: addWishButton.topAnchor, Constants.WishMakerView.buttonBottom)
    }
    
    private func configureToggleButton() {
        toggleButton.setTitle(Constants.WishMakerView.buttonTitleHide, for: .normal)
        toggleButton.setTitleColor(Constants.WishMakerView.buttonTitleColor, for: .normal)
        toggleButton.backgroundColor = Constants.WishMakerView.buttonBackgroundColor
        toggleButton.layer.cornerRadius = Constants.WishMakerView.stackRadius
        toggleButton.layer.borderWidth = Constants.WishMakerView.borderWidth
        toggleButton.addTarget(self, action: #selector(toggleButtonPressed), for: .touchUpInside)
        
        addSubview(toggleButton)
        toggleButton.setHeight(Constants.WishMakerView.buttonHeight)
        toggleButton.pinCenterX(to: centerXAnchor)
        toggleButton.pinLeft(to: stack.leadingAnchor)
        toggleButtonBottomConstraint = toggleButton.bottomAnchor.constraint(equalTo: stack.topAnchor, constant: -Constants.WishMakerView.buttonBottom)
        toggleButtonBottomConstraint?.isActive = true
    }
    
    private func configureAddWishButton() {
        addWishButton.backgroundColor = Constants.WishMakerView.buttonBackgroundColor
        addWishButton.setTitleColor(Constants.WishMakerView.wishButtonTitleColor, for: .normal)
        addWishButton.setTitle(Constants.WishMakerView.wishButtonText, for: .normal)
        addWishButton.layer.cornerRadius = Constants.WishMakerView.stackRadius
        addWishButton.layer.borderWidth = Constants.WishMakerView.borderWidth
        addWishButton.addTarget(self, action: #selector(wishButtonPressed), for: .touchUpInside)
        
        addSubview(addWishButton)
        addWishButton.setHeight(Constants.WishMakerView.buttonHeight)
        addWishButton.pinBottom(to: scheduleButton.topAnchor, Constants.WishMakerView.buttonBottom)
        addWishButton.pinHorizontal(to: self, Constants.WishMakerView.stackLeading)
    }
    
    private func configureScheduleButton() {
        scheduleButton.backgroundColor = Constants.WishMakerView.buttonBackgroundColor
        scheduleButton.setTitleColor(.black, for: .normal)
        scheduleButton.setTitle("Schedule wish granting", for: .normal)
        scheduleButton.layer.cornerRadius = Constants.WishMakerView.stackRadius
        scheduleButton.layer.borderWidth = Constants.WishMakerView.borderWidth
        scheduleButton.addTarget(self, action: #selector (scheduleButtonPressed), for: .touchUpInside)
        
        addSubview(scheduleButton)
        scheduleButton.setHeight(Constants.WishMakerView.buttonHeight)
        scheduleButton.pinBottom(to: safeAreaLayoutGuide.bottomAnchor, Constants.WishMakerView.buttonBottom)
        scheduleButton.pinHorizontal(to: self, Constants.WishMakerView.stackLeading)
    }
    
    private func notifyColorChange() {
        onColorChange?(currentColor)
    }
    
    @objc private func toggleButtonPressed() {
        onToggleButtonPressed?()
        
        toggleButtonBottomConstraint?.isActive = false
        
        if isToggleButtonPinnedToStack {
            toggleButtonBottomConstraint = toggleButton.bottomAnchor.constraint(equalTo: addWishButton.topAnchor, constant: -Constants.WishMakerView.buttonBottom)
        } else {
            toggleButtonBottomConstraint = toggleButton.bottomAnchor.constraint(equalTo: stack.topAnchor, constant: -Constants.WishMakerView.buttonBottom)
        }
        
        toggleButtonBottomConstraint?.isActive = true
        isToggleButtonPinnedToStack.toggle()
        
        UIView.animate(withDuration: Constants.WishMakerView.animationDuration) {
            self.layoutIfNeeded()
        }
    }
    
    @objc private func wishButtonPressed() {
        onWishButtonPressed?()
    }
    
    @objc private func scheduleButtonPressed() {
        onScheduleButtonPressed?()
    }
}
