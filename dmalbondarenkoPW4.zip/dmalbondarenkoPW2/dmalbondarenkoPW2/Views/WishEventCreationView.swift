//
//  WishEventCreationView.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 25.11.2024.
//

import UIKit

class WishEventCreationView: UIView, UITextViewDelegate {
    // MARK: - Variables
    var onButtonTapped: ((String, String?, Date, Date) -> Void)?
    var backPin = UIView()
    private var titleWrap = UIView()
    private var descriptionWrap = UIView()
    private var startDateWrap = UIView()
    private var endDateWrap = UIView()
    private var startDateLabel = UILabel()
    private var endDateLabel = UILabel()
    private var wishEventButton = UIButton()
    
    // MARK: - Constants
    private let titleTextView = UITextView()
    private let descriptionTextView = UITextView()
    private let startDatePicker = UIDatePicker()
    private let endDatePicker = UIDatePicker()
    
    // MARK: - Initialization
    init() {
        super.init(frame: .zero)
        
        configureUI()
    }
    
    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Public Methods
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == Constants.WishEventCreationView.lightGrayColor {
            textView.text = ""
            textView.textColor = Constants.WishEventCreationView.whiteColor
        }
    }

    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = textView == titleTextView ? Constants.WishEventCreationView.defaultText : Constants.WishEventCreationView.descriptionText
            textView.textColor = Constants.WishEventCreationView.lightGrayColor
        }
    }

    // MARK: - Private Methods
    private func configureUI() {
        backgroundColor = Constants.WishEventCreationView.whiteColor
        
        configureBackPin()
        configureTitleText()
        configureDescriptionText()
        configureStartDatePicker()
        configureEndDatePicker()
        configureButton()
    }
    
    private func configureBackPin() {
        addSubview(backPin)
        backPin.pinTop(to: topAnchor, Constants.WishEventCreationView.padding)
        backPin.setHeight(Constants.WishEventCreationView.backPinHeight)
        backPin.setWidth(Constants.WishEventCreationView.backPinWidth)
        backPin.pinCenterX(to: centerXAnchor)
        backPin.backgroundColor = AppState.shared.globalColor.inverted()
        backPin.layer.cornerRadius = Constants.WishEventCreationView.backPinCornerRadius
    }
    
    private func configureTitleText() {
        titleWrap = createWrapView()
        addSubview(titleWrap)
        
        titleWrap.backgroundColor = .darkGray
        titleWrap.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        titleWrap.pinTop(to: topAnchor, Constants.WishEventCreationView.padding * 2)
        titleWrap.pinHorizontal(to: self, Constants.WishEventCreationView.padding)
        titleWrap.setHeight(Constants.WishEventCreationView.buttonHeight)
        
        titleWrap.addSubview(titleTextView)
        configureTextView(titleTextView, placeholder: Constants.WishEventCreationView.defaultText, wrap: titleWrap)
    }
    
    
    private func configureDescriptionText() {
        descriptionWrap = createWrapView()
        addSubview(descriptionWrap)
        
        descriptionWrap.backgroundColor = .darkGray
        descriptionWrap.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        descriptionWrap.pinTop(to: titleWrap.bottomAnchor, Constants.WishEventCreationView.padding)
        descriptionWrap.pinHorizontal(to: self, Constants.WishEventCreationView.padding)
        descriptionWrap.setHeight(Constants.WishEventCreationView.buttonHeight)
        
        descriptionWrap.addSubview(descriptionTextView)
        configureTextView(descriptionTextView, placeholder: Constants.WishEventCreationView.descriptionText, wrap: descriptionWrap)
    }
    
    private func configureStartDatePicker() {
        startDateWrap = createWrapView()
        addSubview(startDateWrap)
        
        startDateWrap.backgroundColor = .darkGray
        startDateWrap.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        startDateWrap.pinTop(to: descriptionWrap.bottomAnchor, Constants.WishEventCreationView.padding)
        startDateWrap.pinHorizontal(to: self, Constants.WishEventCreationView.padding)
        startDateWrap.setHeight(Constants.WishEventCreationView.buttonHeight)
        
        addSubview(startDatePicker)
        startDatePicker.datePickerMode = .date
        startDatePicker.overrideUserInterfaceStyle = .dark
        startDatePicker.backgroundColor = .darkGray
        startDatePicker.pinRight(to: startDateWrap, Constants.WishEventCreationView.padding)
        startDatePicker.pinCenterY(to: startDateWrap.centerYAnchor)
        
        startDateLabel = createLabel(text: Constants.WishEventCreationView.startDateLabelText, color: Constants.WishEventCreationView.lightGrayColor)
        startDateWrap.addSubview(startDateLabel)
        startDateLabel.pinLeft(to: startDateWrap, Constants.WishEventCreationView.labelLeftOffset)
        startDateLabel.pinCenterY(to: startDateWrap.centerYAnchor)
    }
    
    private func configureEndDatePicker() {
        endDateWrap = createWrapView()
        addSubview(endDateWrap)
        
        endDateWrap.backgroundColor = .darkGray
        endDateWrap.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        endDateWrap.pinTop(to: startDateWrap.bottomAnchor, Constants.WishEventCreationView.padding)
        endDateWrap.pinHorizontal(to: self, Constants.WishEventCreationView.padding)
        endDateWrap.setHeight(Constants.WishEventCreationView.buttonHeight)
        
        addSubview(endDatePicker)
        endDatePicker.datePickerMode = .date
        endDatePicker.overrideUserInterfaceStyle = .dark
        endDatePicker.backgroundColor = .darkGray
        endDatePicker.pinRight(to: endDateWrap, Constants.WishEventCreationView.padding)
        endDatePicker.pinCenterY(to: endDateWrap.centerYAnchor)
        
        endDateLabel = createLabel(text: Constants.WishEventCreationView.endDateLabelText, color: Constants.WishEventCreationView.lightGrayColor)
        endDateWrap.addSubview(endDateLabel)
        endDateLabel.pinLeft(to: endDateWrap, Constants.WishEventCreationView.labelLeftOffset)
        endDateLabel.pinCenterY(to: endDateWrap.centerYAnchor)
    }
    
    private func configureButton() {
        addSubview(wishEventButton)
        
        wishEventButton.setTitle(Constants.WishEventCreationView.buttonNormalTitle, for: .normal)
        wishEventButton.setTitleColor(Constants.WishEventCreationView.buttonTitleColor, for: .normal)
        wishEventButton.backgroundColor = Constants.WishEventCreationView.buttonBackgroundColor
        wishEventButton.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        wishEventButton.pinTop(to: endDateWrap.bottomAnchor, Constants.WishEventCreationView.padding)
        wishEventButton.setHeight(Constants.WishEventCreationView.buttonHeight)
        wishEventButton.pinHorizontal(to: self, Constants.WishEventCreationView.padding)
        wishEventButton.addTarget(self, action: #selector(didTapWishEventButton), for: .touchUpInside)
    }
    
    private func createWrapView() -> UIView {
        let wrap = UIView()
        wrap.backgroundColor = .darkGray
        wrap.layer.cornerRadius = Constants.WishEventCreationView.cornerRadius
        return wrap
    }
    
    private func createLabel(text: String, color: UIColor) -> UILabel {
        let label = UILabel()
        label.text = text
        label.textColor = color
        label.font = UIFont.systemFont(ofSize: Constants.WishEventCreationView.labelFontSize)
        return label
    }
    
    private func configureTextView(_ textView: UITextView, placeholder: String, wrap: UIView) {
        textView.backgroundColor = wrap.backgroundColor
        textView.text = placeholder
        textView.font = UIFont.systemFont(ofSize: Constants.WishEventCreationView.textViewFontSize)
        textView.textColor = Constants.WishEventCreationView.lightGrayColor
        textView.isScrollEnabled = true
        textView.textContainer.maximumNumberOfLines = 3
        textView.textContainer.lineBreakMode = .byWordWrapping
        textView.delegate = self
        textView.pinHorizontal(to: wrap, Constants.WishEventCreationView.labelLeftOffset)
        textView.pinVertical(to: wrap, Constants.WishEventCreationView.labelLeftOffset)
    }
    
    @objc private func didTapWishEventButton() {
        if titleTextView.textColor != Constants.WishEventCreationView.lightGrayColor {
            let note = descriptionTextView.textColor == Constants.WishEventCreationView.lightGrayColor ? "" : descriptionTextView.text
            onButtonTapped?(titleTextView.text, note, startDatePicker.date, endDatePicker.date)
            titleTextView.text = Constants.WishEventCreationView.defaultText
            titleTextView.textColor = Constants.WishEventCreationView.lightGrayColor
            descriptionTextView.text = Constants.WishEventCreationView.descriptionText
            descriptionTextView.textColor = Constants.WishEventCreationView.lightGrayColor
            startDatePicker.date = Date()
            endDatePicker.date = Date()
        }
    }
}
