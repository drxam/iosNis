//
//  WishStoringViewController+UITableViewDataSource.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 10.11.2024.
//

import UIKit

// MARK: - UITableViewDataSource
extension WishStoringViewController: UITableViewDataSource {
    
    // MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? 1 : wishArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: AddWishCell.reuseId, for: indexPath)
            
            guard let addWishCell = cell as? AddWishCell else { return cell }
            
            addWishCell.addWish = { [weak self] wishText in
                self?.wishArray.append(wishText)
                tableView.reloadData()
                self?.userDefaultsHelper.saveWishes(self?.wishArray ?? [])
            }
            
            addWishCell.addWishButton.backgroundColor = AppState.shared.globalColor
            addWishCell.addWishButton.setTitleColor(AppState.shared.globalColor.inverted(), for: .normal)
            
            return addWishCell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: WrittenWishCell.reuseId, for: indexPath)
            
            guard let wishCell = cell as? WrittenWishCell else { return cell }
            wishCell.configure(with: wishArray[indexPath.row])
            
            wishCell.deleteWish = { [weak self] in
                guard let self = self else { return }
                self.wishArray.remove(at: indexPath.row)
                tableView.reloadData()
                self.userDefaultsHelper.saveWishes(self.wishArray)
            }
            
            wishCell.editWish = { [weak self] in
                self?.handleEditWish(at: indexPath.row)
            }
            
            wishCell.deleteWishButton.backgroundColor = AppState.shared.globalColor
            wishCell.deleteWishButton.setTitleColor(AppState.shared.globalColor.inverted(), for: .normal)
            wishCell.editWishButton.backgroundColor = AppState.shared.globalColor
            wishCell.editWishButton.setTitleColor(AppState.shared.globalColor.inverted(), for: .normal)
            
            return wishCell
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return Constants.WishStoringViewController.numberOfSections
    }
}
