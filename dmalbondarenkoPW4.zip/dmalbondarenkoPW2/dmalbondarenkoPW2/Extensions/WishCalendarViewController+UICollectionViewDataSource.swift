//
//  WishCalendarViewController+UICollectionViewDataSource.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 24.11.2024.
//

import UIKit

extension WishCalendarViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return wishEventArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: WishEventCell.reuseId, for: indexPath)
        guard let wishEventCell = cell as? WishEventCell else { return cell }
        
        wishEventCell.configure(
                with: WishEventModel(
                    title: wishEventArray[indexPath.row].title,
                    note: wishEventArray[indexPath.row].note,
                    startDate: wishEventArray[indexPath.row].startDate,
                    endDate: wishEventArray[indexPath.row].endDate
                )
            )
        
        return wishEventCell
    }
}
