//
//  AppState.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 01.12.2024.
//

import Foundation
import UIKit

class AppState {
    static let shared = AppState()
    var globalColor: UIColor = UIColor(
        red: Constants.AppStateConsts.colorValue,
        green: Constants.AppStateConsts.colorValue,
        blue: Constants.AppStateConsts.colorValue,
        alpha: Constants.AppStateConsts.alphaValue
    )
}
