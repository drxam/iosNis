//
//  WishEventModel.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 24.11.2024.
//

import Foundation
import CoreData

struct WishEventModel {
    let title: String
    let note: String?
    let startDate: Date
    let endDate: Date
}

extension WishEventModel {
    init(from entity: WishEvent) {
        self.title = entity.title ?? ""
        self.note = entity.note ?? ""
        self.startDate = entity.startDate ?? Date()
        self.endDate = entity.endDate ?? Date()
    }
}
