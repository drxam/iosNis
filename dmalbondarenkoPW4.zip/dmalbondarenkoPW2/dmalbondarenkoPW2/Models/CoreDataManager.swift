//
//  CoreDataManager.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 30.11.2024.
//

import CoreData
import UIKit

class CoreDataManager {
    static let shared = CoreDataManager()
    private init() {}

    lazy var context: NSManagedObjectContext = {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            fatalError("Unable to get AppDelegate")
        }
        return appDelegate.persistentContainer.viewContext
    }()

    func addWishEvent(title: String, note: String, startDate: Date, endDate: Date) {
        let wishEvent = WishEvent(context: context)
        wishEvent.title = title
        wishEvent.note = note
        wishEvent.startDate = startDate
        wishEvent.endDate = endDate
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.saveContext()
    }
    
    func saveContext() {
            if context.hasChanges {
                do {
                    try context.save()
                } catch {
                    let nserror = error as NSError
                    fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
                }
            }
        }

    func fetchWishEvents() -> [WishEvent] {
        let fetchRequest: NSFetchRequest<WishEvent> = WishEvent.fetchRequest()
        do {
            let wishEvents = try context.fetch(fetchRequest)
            return wishEvents
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
}

