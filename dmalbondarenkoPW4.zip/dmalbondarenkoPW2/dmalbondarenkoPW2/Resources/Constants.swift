//
//  Constants.swift
//  dmalbondarenkoPW2
//
//  Created by dread on 03.11.2024.
//

import UIKit

enum Constants {
    // MARK: - WishMakerView
    enum WishMakerView {
        static let alphaValue: CGFloat = 1.0
        static let colorValue = 0.3
        static let sliderMin: Double = 0
        static let sliderMax: Double = 1
        static let animationDuration: TimeInterval = 0.5
        
        static let titleText: String = "WishMaker"
        static let descriptionText: String =  "In this world, is the destiny of mankind controlled by some transcendental entity or law?\n" +
        "Is it like the hand of God hovering above?\n" +
        "At least it is true that man has no control; even over his own will."
        static let wishButtonText: String = "My wishes"
        static let buttonTitleShow = "Show sliders"
        static let buttonTitleHide = "Hide sliders"
        static let red = "Red"
        static let green = "Green"
        static let blue = "Blue"
        
        static let buttonTitleColor: UIColor = .black
        static let buttonBackgroundColor: UIColor = .white
        static let wishButtonTitleColor: UIColor = .systemPink
        
        static let titleSize: CGFloat = 32
        static let descriptionSize: CGFloat = 16
        static let buttonBottom: CGFloat = 10
        static let buttonHeight: CGFloat = 40
        static let stackRadius: CGFloat = 20
        static let borderWidth = 1.0
        static let stackLeading: CGFloat = 20
        static let titleTopPadding: CGFloat = 30
        static let descriptionPadding: CGFloat = 20
    }
    
    // MARK: - CustomSlider
    enum CustomSlider {
        static let titleTop: Double = 10
        static let titleLeft: Double = 20
        static let sliderBottom: Double = 10
        static let sliderLeft: Double = 20
        static let sliderValue : Float = 0.25
    }
    
    // MARK: - WishStoringView
    enum WishStoringView {
        static let backPinTopOffset: CGFloat = 5
        static let backPinHeight: CGFloat = 6
        static let backPinWidth: CGFloat = 70
        static let backPinCornerRadius: CGFloat = 3
        static let tableCornerRadius: CGFloat = 20
        static let tableOffset: CGFloat = 40
    }
    
    // MARK: - WrittenWishCell
    enum WrittenWishCell {
        static let wrapColor: UIColor = .white
        static let wrapRadius: CGFloat = 16
        static let wrapOffsetV: CGFloat = 5
        static let wrapOffsetH: CGFloat = 10
        
        static let deleteButtonTitle: String = "-"
        static let deleteButtonTitleColor: UIColor = .black
        static let deleteButtonBackgroundColor: UIColor = .green
        static let buttonCornerRadius: CGFloat = 20
        static let buttonFontSize: CGFloat = 26
        static let buttonWidth: CGFloat = 40
        
        static let editButtonTitle: String = "✎"
        static let editButtonTitleColor: UIColor = .black
        static let editButtonBackgroundColor: UIColor = .yellow
        
        static let wishLabelOffset: CGFloat = 8
        static let labelFontSize: CGFloat = 16
    }
    
    // MARK: - AddWishCell
    enum AddWishCell {
        static let wrapColor: UIColor = .white
        static let wrapRadius: CGFloat = 16
        static let wrapOffsetV: CGFloat = 5
        static let wrapOffsetH: CGFloat = 10
        
        static let placeholderText: String = "Enter your wish here"
        static let wishTextViewFontSize: CGFloat = 16
        static let wishLabelOffset: CGFloat = 8
        
        static let addWishButtonTitle: String = "+"
        static let buttonTitleColor: UIColor = .black
        static let addWishButtonFontSize: CGFloat = 26
        static let buttonBackgroundGreenColor: UIColor = .green
        static let stackRadius: CGFloat = 20
        static let addWishButtonWidth: CGFloat = 50
    }
    
    // MARK: - WishCalendarView
    enum WishCalendarView {
        static let collectionBackgroundColor: UIColor = .white
        static let collectionContentInset: UIEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
    }
    
    // MARK: - WishEventCell
    enum WishEventCell {
        static let tableCornerRadius: CGFloat = 20
        static let wrapBackgroundColor: UIColor = .darkGray
        static let wrapPadding: CGFloat = 5
        
        static let titleLabelTextColor: UIColor = .white
        static let titleLabelFontSize: CGFloat = 16
        static let titleLabelFont: UIFont = UIFont.boldSystemFont(ofSize: titleLabelFontSize)
        static let titleLabelTopPadding: CGFloat = 10
        static let titleLabelLeftPadding: CGFloat = 10
        static let titleLabelRightPadding: CGFloat = 5
        static let titleLabelHeight: CGFloat = 20
        
        static let descriptionLabelTextColor: UIColor = .lightGray
        static let descriptionLabelFontSize: CGFloat = 12
        static let descriptionLabelFont: UIFont = UIFont.systemFont(ofSize: descriptionLabelFontSize)
        static let descriptionLabelLeftPadding: CGFloat = 10
        static let descriptionLabelRightPadding: CGFloat = 5
        static let descriptionLabelBottomPadding: CGFloat = 10
        
        static let startDateLabelTextColor: UIColor = .white
        static let startDateLabelFontSize: CGFloat = 15
        static let startDateLabelFont: UIFont = UIFont.systemFont(ofSize: startDateLabelFontSize)
        static let startDateLabelSpacing: CGFloat = 5
        
        static let endDateLabelTextColor: UIColor = .white
        static let endDateLabelFontSize: CGFloat = 15
        static let endDateLabelFont: UIFont = UIFont.systemFont(ofSize: endDateLabelFontSize)
        static let endDateLabelWidth: CGFloat = 90
        static let endDateLabelRightPadding: CGFloat = 10
        
        static let dateFormatterFormat: String = "dd.MM.yyyy"
    }
    
    // MARK: - WishEventCreationView
    enum WishEventCreationView {
        static let cornerRadius: CGFloat = 10
        static let padding: CGFloat = 20
        static let buttonHeight: CGFloat = 50
        static let backPinHeight: CGFloat = 6
        static let backPinWidth: CGFloat = 70
        static let labelLeftOffset: CGFloat = 12
        static let labelFontSize: CGFloat = 16
        static let datePickerHeight: CGFloat = 50
        
        static let defaultText: String = "Title"
        static let descriptionText: String = "Description"
        static let lightGrayColor: UIColor = .lightGray
        static let whiteColor: UIColor = .white
        static let textViewFontSize: CGFloat = 16
        
        static let buttonNormalTitle: String = "Create wish event"
        static let buttonBackgroundColor: UIColor = .darkGray
        static let buttonTitleColor: UIColor = .white
        
        static let startDateLabelText: String = "Start date"
        static let endDateLabelText: String = "End date"
        static let labelTextColor: UIColor = .lightGray
        
        static let backPinBackgroundColor: UIColor = AppState.shared.globalColor.inverted()
        static let backPinCornerRadius: CGFloat = 3
    }
    
    // MARK: - AppStateConsts
    enum AppStateConsts {
        static let colorValue = 0.3
        static let alphaValue: CGFloat = 1.0
    }
    
    // MARK: - UserDefaultsHelper
    enum UserDefaultsHelper {
        static let wishesKey = "wishes"
    }
    
    // MARK: - WishStoringViewController
    enum WishStoringViewController {
        static let alertSaveTitle: String = "Save"
        static let alertCancelTitle: String = "Cancel"
        static let alertEditTitle: String = "Edit Wish"
        static let numberOfSections = 2
    }
    
//    // MARK: - Stack and Layout Constants
//    static let stackBottom: CGFloat = 40
//    
//    // MARK: - TableView Constants
//    static let tableBackgroundColor: UIColor = .red
//    static let tableOffset: CGFloat = 40
//       
//    // MARK: - ViewController Constants
//    static let blueBackgroundColor: UIColor = .blue
    
}
